# -*- coding: utf-8 -*-
import scrapy
from pymongo import MongoClient
import pprint



class GoodreadsFetchBookurlsSpider(scrapy.Spider):
    name = 'goodreads_fetch_bookurls'
    allowed_domains = ['www.goodreads.com']
    start_urls = []

    # def get_starturls():
    #     url_list = []
    #     client = MongoClient()
    #     db = client.books
    #     collection = db.goodreads_listurls
    #     for cursor_obj in collection.find({"status":"pending"}):
    #         url_list.append(cursor_obj['url'])
    #     return url_list
    #
    # start_urls = get_starturls()
    

    client = MongoClient()
    db = client.books
    collection = db.goodreads_bookurls
    insert_count = 0

    def parse(self, response):
        book_rows = response.xpath("//table[contains(@class, 'tableList')]//tr")
        for row in book_rows:
            book_link = response.urljoin(row.xpath(".//a[@class='bookTitle']/@href").get())
            book = {
                'url':book_link
            }
            # yield book
            if not self.collection.find_one(book):
                self.collection.insert_one(book).inserted_id
                self.insert_count += 1
                print('Book url inserted in DB, count = {}'.format(self.insert_count))
            else:
                print('Duplicate book url, skipped.')

        next_page = response.xpath("//a[@class='next_page']/@href").get()
        if next_page:
            yield response.follow(url=next_page, callback=self.parse)
