from pymongo import MongoClient


def get_urls():
    client = MongoClient()
    db = client['books']
    col_bookurls = db['book_urls']
    url_list = []
    cursor = col_bookurls.find(filter={'status': 'pending'})

    batch_size = 1000
    for i in range(cursor.count()//batch_size):
        url_list.clear()
        for j in range(i * batch_size, (i * batch_size) + batch_size):
            url_list.append(cursor[j]['url'])
        yield url_list

if __name__ == '__main__':
    pass