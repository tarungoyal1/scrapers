# -*- coding: utf-8 -*-
import scrapy
from pymongo import MongoClient


class GoodreadsGetlisturlsSpider(scrapy.Spider):
    name = 'goodreads_getlisturls'
    allowed_domains = ['www.goodreads.com']
    start_urls = ['https://www.goodreads.com/list/tag/nonfiction']

    # def get_starturls():
    #     url_list = []
    #     client = MongoClient()
    #     db = client.books
    #     collection = db.goodreads_listurls
    #     for cursor_obj in collection.find({"status":"pending"}):
    #         url_list.append(cursor_obj['url'])
    #     return url_list
    #
    # start_urls = get_starturls()

    client = MongoClient()
    db = client.books
    collection = db.goodreads_listurls
    insert_count = 0

    def parse(self, response):
        list_urls = response.xpath("//div[@class='listRowsFull']//div[@class='cell']")
        for book_li in list_urls:
            list_link = response.urljoin(book_li.xpath(".//a[@class='listTitle']/@href").get())
            list_obj = {
                'url':list_link,
                'status':'pending'
            }
            # yield book
            if not self.collection.find_one({'url':list_link}):
                self.collection.insert_one(list_obj).inserted_id
                self.insert_count += 1
                print('List url inserted in DB, count = {}'.format(self.insert_count))
            else:
                print('Duplicate list url, skipped.')
            
        
        next_page = response.xpath("//a[@class='next_page']/@href").get()
        if next_page:
            yield response.follow(url=next_page, callback=self.parse)
