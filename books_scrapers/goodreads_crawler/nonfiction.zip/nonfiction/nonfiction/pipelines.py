#-*- coding: utf-8 -*-

from pymongo import MongoClient

class NonfictionPipeline:

    def open_spider(self, spider):
        "mongodb+srv://omen:OkICaNE7O5YRthEJ@bookstore.tsksz.gcp.mongodb.net/books?retryWrites=true&w=majority"
        self.client = MongoClient()
        self.db = self.client['books']
        self.col_bookinfo = self.db['book_info']
        self.col_bookurls = self.db['book_urls']
        # self.col_bookurls = self.db['goodreads_bookurls']


    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if not self.col_bookinfo.find_one({'book_url':item['book_url']}):
            if self.col_bookinfo.insert_one(item).inserted_id:
                # self.insert_count += 1
                # print('{}'.format(self.insert_count))
                #update the status of this book in book
                if self.col_bookurls.update_one({'url': item['book_url']}, {'$set': {'status': 'done'}}, False).modified_count==1:
                    print('Status updated, url  = {}'.format(item['book_url']))
                    return True
        else:
            # print('Duplicate book url, skipped.')
            return False
        return item
