# import scrapy
# from scrapy.crawler import CrawlerProcess
# from nonfiction.spiders.get_book_details import GetBookDetailsSpider1, GetBookDetailsSpider3
# from nonfiction.spiders.get_book_details_2 import GetBookDetailsSpider2, GetBookDetailsSpider4
#
# process = CrawlerProcess()
# process.crawl(GetBookDetailsSpider1)
# process.crawl(GetBookDetailsSpider2)
# process.crawl(GetBookDetailsSpider3)
# process.crawl(GetBookDetailsSpider4)
# process.start()